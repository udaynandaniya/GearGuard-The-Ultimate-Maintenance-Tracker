# 🚀 Quick Command Reference - GearGuard

All commands you need to run GearGuard in VS Code.

---

## 📋 Initial Setup (One-Time)

### 1. Open Project in VS Code
```bash
cd "/Users/madhakvivek/Desktop/GearGuard_ The Ultimate Maintenance Tracker"
code .
```

### 2. Create Virtual Environment
```bash
python3 -m venv venv
```

### 3. Activate Virtual Environment

**Mac/Linux:**
```bash
source venv/bin/activate
```

**Windows (PowerShell):**
```bash
.\venv\Scripts\Activate.ps1
```

**Windows (CMD):**
```bash
venv\Scripts\activate.bat
```

### 4. Install Dependencies
```bash
pip install -r requirements.txt
```

### 5. Create Database
```bash
python manage.py makemigrations
python manage.py migrate
```

### 6. Load Sample Data
```bash
python manage.py create_sample_data
```

---

## 🔄 Daily Use Commands

### Start Development Server
```bash
# Make sure venv is activated first!
python manage.py runserver
```

**Access:** http://127.0.0.1:8000/

### Stop Server
```bash
# Press Ctrl + C in terminal
```

### Run on Different Port
```bash
python manage.py runserver 8001
```

---

## 🗄️ Database Commands

### Create New Migration
```bash
python manage.py makemigrations
```

### Apply Migrations
```bash
python manage.py migrate
```

### Show Migration Status
```bash
python manage.py showmigrations
```

### Reset Database (⚠️ Deletes All Data)
```bash
rm db.sqlite3  # Mac/Linux
del db.sqlite3  # Windows
python manage.py migrate
python manage.py create_sample_data
```

---

## 👤 User Management

### Create Superuser (Admin)
```bash
python manage.py createsuperuser
```

### Reload Sample Data
```bash
python manage.py create_sample_data
```

---

## 🔍 Utility Commands

### Check for Errors
```bash
python manage.py check
```

### Open Django Shell
```bash
python manage.py shell
```

### Collect Static Files
```bash
python manage.py collectstatic
```

---

## 🐍 Python Environment

### Check Python Version
```bash
python --version
python3 --version
```

### Check Installed Packages
```bash
pip list
```

### Upgrade pip
```bash
pip install --upgrade pip
```

### Install Specific Package
```bash
pip install package-name
```

---

## 🔧 Troubleshooting Commands

### Reinstall Dependencies
```bash
pip install --upgrade -r requirements.txt
```

### Check Django Version
```bash
python -c "import django; print(django.get_version())"
```

### Verify Virtual Environment
```bash
which python  # Mac/Linux
where python  # Windows
# Should show: .../venv/bin/python
```

### Deactivate Virtual Environment
```bash
deactivate
```

---

## 📁 File Operations

### List Files
```bash
ls  # Mac/Linux
dir  # Windows
```

### Navigate Directories
```bash
cd folder-name
cd ..  # Go back
cd ~  # Home directory
```

### Create Directory
```bash
mkdir folder-name
```

### Delete File
```bash
rm file-name  # Mac/Linux
del file-name  # Windows
```

---

## 🌐 Server URLs

- **Main App:** http://127.0.0.1:8000/
- **Admin Panel:** http://127.0.0.1:8000/admin/
- **Dashboard:** http://127.0.0.1:8000/
- **Equipment:** http://127.0.0.1:8000/equipment/
- **Requests:** http://127.0.0.1:8000/requests/
- **Kanban:** http://127.0.0.1:8000/kanban/
- **Calendar:** http://127.0.0.1:8000/calendar/
- **Reports:** http://127.0.0.1:8000/reports/

---

## 🔑 Test Accounts

After running `create_sample_data`:

```bash
Username: john.electrician
Password: password123

Username: jane.electrician
Password: password123

Username: bob.mechanic
Password: password123

Username: alice.itsupport
Password: password123
```

---

## ⚡ Quick Start Sequence

Copy and paste these commands in order:

```bash
# 1. Navigate to project
cd "/Users/madhakvivek/Desktop/GearGuard_ The Ultimate Maintenance Tracker"

# 2. Activate venv (if not already activated)
source venv/bin/activate  # Mac/Linux
# OR
.\venv\Scripts\Activate.ps1  # Windows

# 3. Start server
python manage.py runserver
```

---

## 📝 Common Workflows

### Workflow 1: First Time Setup
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py create_sample_data
python manage.py runserver
```

### Workflow 2: Daily Development
```bash
source venv/bin/activate
python manage.py runserver
```

### Workflow 3: After Code Changes
```bash
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```

### Workflow 4: Reset Everything
```bash
rm -rf venv
rm db.sqlite3
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py create_sample_data
```

---

## 🎯 VS Code Shortcuts

- **Open Terminal:** `Ctrl + ~` (Windows/Linux) or `Cmd + ~` (Mac)
- **Command Palette:** `Ctrl + Shift + P` (Windows/Linux) or `Cmd + Shift + P` (Mac)
- **Select Python Interpreter:** `Ctrl + Shift + P` → "Python: Select Interpreter"
- **Format Document:** `Shift + Alt + F` (Windows/Linux) or `Shift + Option + F` (Mac)
- **Save All:** `Ctrl + K, S`

---

## 💡 Pro Tips

1. **Always activate venv before running commands**
2. **Keep terminal open while server is running**
3. **Use `Ctrl + C` to stop server, don't close terminal**
4. **Check `(venv)` in prompt to confirm activation**
5. **Run `python manage.py check` if something breaks**

---

**Save this file for quick reference! 📌**

