# Quick Start Guide - GearGuard

## 🚀 Get Started in 5 Minutes

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Setup Database
```bash
python manage.py migrate
```

### Step 3: Create Sample Data
```bash
python manage.py create_sample_data
```

### Step 4: Run Server
```bash
python manage.py runserver
```

### Step 5: Access Application
Open browser: http://127.0.0.1:8000/

## 🔑 Test Accounts

After running `create_sample_data`, you can login with:

- **Username:** `john.electrician` | **Password:** `password123` (Electrical Team)
- **Username:** `jane.electrician` | **Password:** `password123` (Electrical Team)
- **Username:** `bob.mechanic` | **Password:** `password123` (Mechanical Team)
- **Username:** `alice.itsupport` | **Password:** `password123` (IT Support Team)

## 📍 Key Features to Test

1. **Dashboard** - View statistics and recent requests
2. **Equipment List** - Browse all equipment
3. **Create Request** - Create a new maintenance request
4. **Kanban Board** - Drag and drop requests between statuses
5. **Calendar View** - See preventive maintenance schedule
6. **Reports** - View analytics and statistics

## 🎯 Try These Workflows

### Workflow 1: Create Equipment
1. Go to Equipment → Add Equipment
2. Fill in details and assign a team
3. Save

### Workflow 2: Create Maintenance Request
1. Go to Requests → New Request
2. Select equipment (team auto-fills!)
3. Choose type (Corrective/Preventive)
4. Set scheduled date
5. Save

### Workflow 3: Technician Assignment
1. Login as a technician (e.g., `john.electrician`)
2. Go to a request from your team
3. Click "Assign Myself"
4. Status changes to "In Progress"

### Workflow 4: Complete Request
1. As assigned technician, go to request detail
2. Click "Mark as Repaired"
3. Enter duration (optional)
4. Status changes to "Repaired"

### Workflow 5: Kanban Drag & Drop
1. Go to Kanban Board
2. Drag a request card to different status column
3. Status updates automatically!

## 🐛 Troubleshooting

**Issue:** "No module named 'crispy_forms'"
- **Solution:** Run `pip install -r requirements.txt`

**Issue:** "Table doesn't exist"
- **Solution:** Run `python manage.py migrate`

**Issue:** "Static files not loading"
- **Solution:** Run `python manage.py collectstatic` (optional for development)

**Issue:** Can't login
- **Solution:** Run `python manage.py create_sample_data` to create test users

## 📚 Next Steps

- Read the full README.md for detailed documentation
- Explore the admin panel at /admin/
- Create your own equipment and requests
- Customize the system for your needs

---

**Happy Maintaining! 🛠️**

