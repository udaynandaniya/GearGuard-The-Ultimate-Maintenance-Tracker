# 🚀 VS Code Setup Guide - GearGuard

Complete step-by-step guide to run GearGuard in Visual Studio Code.

---

## 📋 Prerequisites

Before starting, ensure you have:
- ✅ Visual Studio Code installed
- ✅ Python 3.8 or higher installed
- ✅ Git (optional, for version control)

---

## 🔧 Step 1: Open Project in VS Code

### Option A: From VS Code
1. Open Visual Studio Code
2. Click **File** → **Open Folder**
3. Navigate to: `GearGuard_ The Ultimate Maintenance Tracker`
4. Click **Select Folder**

### Option B: From Terminal
```bash
cd "/Users/madhakvivek/Desktop/GearGuard_ The Ultimate Maintenance Tracker"
code .
```

---

## 🐍 Step 2: Check Python Installation

### Open Terminal in VS Code
- Press `Ctrl + ~` (Windows/Linux) or `Cmd + ~` (Mac)
- Or go to **Terminal** → **New Terminal**

### Check Python Version
```bash
python --version
# OR
python3 --version
```

**Expected Output:** `Python 3.8.x` or higher

**If Python is not installed:**
- Windows: Download from [python.org](https://www.python.org/downloads/)
- Mac: `brew install python3`
- Linux: `sudo apt-get install python3`

---

## 📦 Step 3: Create Virtual Environment

### Why Virtual Environment?
- Isolates project dependencies
- Prevents conflicts with other projects
- Best practice for Python development

### Create Virtual Environment
```bash
# Navigate to project directory (if not already there)
cd "/Users/madhakvivek/Desktop/GearGuard_ The Ultimate Maintenance Tracker"

# Create virtual environment
python3 -m venv venv

# OR if python3 doesn't work, try:
python -m venv venv
```

**Expected Output:** A new `venv` folder will be created

---

## 🔌 Step 4: Activate Virtual Environment

### For Windows (PowerShell)
```bash
.\venv\Scripts\Activate.ps1
```

**If you get an error about execution policy:**
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### For Windows (Command Prompt)
```bash
venv\Scripts\activate.bat
```

### For Mac/Linux
```bash
source venv/bin/activate
```

**Success Indicator:** You'll see `(venv)` at the start of your terminal prompt:
```
(venv) user@computer:~/GearGuard_ The Ultimate Maintenance Tracker$
```

---

## 📥 Step 5: Install Dependencies

### Install Required Packages
```bash
# Make sure virtual environment is activated (you see (venv) in prompt)
pip install -r requirements.txt
```

**Expected Output:**
```
Collecting Django==4.2.7
Collecting django-crispy-forms==2.1
Collecting crispy-bootstrap5==0.7
Installing collected packages: ...
Successfully installed Django-4.2.7 django-crispy-forms-2.1 crispy-bootstrap5-0.7
```

### If Installation Fails

**Error: "pip is not recognized"**
```bash
python -m pip install -r requirements.txt
```

**Error: "No module named pip"**
```bash
python -m ensurepip --upgrade
python -m pip install -r requirements.txt
```

**Error: Permission Denied**
```bash
# Don't use sudo on Windows/Mac with venv
# Just make sure venv is activated
pip install --user -r requirements.txt
```

---

## 🗄️ Step 6: Setup Database

### Create Database Migrations
```bash
# Make sure you're in project root and venv is activated
python manage.py makemigrations
```

**Expected Output:**
```
Migrations for 'maintenance':
  maintenance/migrations/0001_initial.py
    - Create model Department
    - Create model Equipment
    - Create model MaintenanceTeam
    - Create model Technician
    - Create model MaintenanceRequest
```

### Apply Migrations
```bash
python manage.py migrate
```

**Expected Output:**
```
Operations to perform:
  Apply all migrations: admin, auth, contenttypes, maintenance, sessions
Running migrations:
  Applying contenttypes.0001_initial... OK
  Applying auth.0001_initial... OK
  ...
  Applying maintenance.0001_initial... OK
```

---

## 👤 Step 7: Create Sample Data (Optional but Recommended)

### Load Sample Data
```bash
python manage.py create_sample_data
```

**Expected Output:**
```
Creating sample data...
Creating departments...
Creating maintenance teams...
Creating users and technicians...
Creating equipment...
Creating maintenance requests...

Sample data created successfully!

Test Accounts:
  - john.electrician / password123 (Electrical Team)
  - jane.electrician / password123 (Electrical Team)
  - bob.mechanic / password123 (Mechanical Team)
  - alice.itsupport / password123 (IT Support Team)
```

---

## 🎯 Step 8: Run Development Server

### Start Server
```bash
python manage.py runserver
```

**Expected Output:**
```
Watching for file changes with StatReloader
Performing system checks...

System check identified no issues (0 silenced).
December 12, 2024 - 15:30:45
Django version 4.2.7, using settings 'gearguard.settings'
Starting development server at http://127.0.0.1:8000/
Quit the server with CTRL-BREAK.
```

### Access Application
1. Open your web browser
2. Go to: **http://127.0.0.1:8000/**
3. You should see the GearGuard login page

### Stop Server
- Press `Ctrl + C` in the terminal

---

## 🧪 Step 9: Test the Application

### Login with Test Account
1. Go to: http://127.0.0.1:8000/
2. Click **Register** or use existing account
3. Login with:
   - Username: `john.electrician`
   - Password: `password123`

### Explore Features
- ✅ Dashboard - View statistics
- ✅ Equipment - Browse equipment list
- ✅ Requests - View maintenance requests
- ✅ Kanban - Drag and drop board
- ✅ Calendar - Preventive maintenance view
- ✅ Reports - Analytics

---

## ⚙️ Step 10: VS Code Extensions (Recommended)

### Install Python Extension
1. Open VS Code Extensions: `Ctrl + Shift + X` (or `Cmd + Shift + X` on Mac)
2. Search for: **Python**
3. Install by Microsoft

### Install Django Extension (Optional)
1. Search for: **Django**
2. Install: **Django** by Baptiste Darthenay

### Configure Python Interpreter
1. Press `Ctrl + Shift + P` (or `Cmd + Shift + P` on Mac)
2. Type: `Python: Select Interpreter`
3. Choose: `./venv/bin/python` (or `.\venv\Scripts\python.exe` on Windows)

---

## 🔍 Step 11: Verify Setup

### Run System Check
```bash
python manage.py check
```

**Expected Output:**
```
System check identified no issues (0 silenced).
```

### Check Database
```bash
# List all tables
python manage.py showmigrations
```

---

## 🐛 Troubleshooting Common Issues

### Issue 1: "ModuleNotFoundError: No module named 'django'"

**Solution:**
```bash
# Make sure venv is activated
source venv/bin/activate  # Mac/Linux
# OR
venv\Scripts\activate  # Windows

# Reinstall dependencies
pip install -r requirements.txt
```

### Issue 2: "No changes detected" when running makemigrations

**Solution:**
```bash
# Force create migrations
python manage.py makemigrations maintenance
python manage.py migrate
```

### Issue 3: "Port 8000 already in use"

**Solution:**
```bash
# Use different port
python manage.py runserver 8001

# OR kill process on port 8000
# Windows:
netstat -ano | findstr :8000
taskkill /PID <PID> /F

# Mac/Linux:
lsof -ti:8000 | xargs kill -9
```

### Issue 4: "Database is locked" (SQLite)

**Solution:**
```bash
# Close all database connections
# Restart VS Code
# Or delete db.sqlite3 and re-migrate:
rm db.sqlite3  # Mac/Linux
del db.sqlite3  # Windows
python manage.py migrate
python manage.py create_sample_data
```

### Issue 5: "Static files not loading"

**Solution:**
```bash
# Create static directory
mkdir static

# Collect static files (for production)
python manage.py collectstatic --noinput
```

### Issue 6: Virtual Environment Not Activating

**Solution:**
```bash
# Delete and recreate venv
rm -rf venv  # Mac/Linux
rmdir /s venv  # Windows

# Recreate
python3 -m venv venv
source venv/bin/activate  # Mac/Linux
venv\Scripts\activate  # Windows
```

### Issue 7: "Command 'python' not found"

**Solution:**
```bash
# Use python3 instead
python3 manage.py runserver

# OR create alias (Mac/Linux)
alias python=python3
```

---

## 📝 Quick Command Reference

### Daily Development Commands

```bash
# Activate virtual environment
source venv/bin/activate  # Mac/Linux
venv\Scripts\activate  # Windows

# Start server
python manage.py runserver

# Create new migration
python manage.py makemigrations

# Apply migrations
python manage.py migrate

# Create superuser (for admin)
python manage.py createsuperuser

# Run tests (if you add tests)
python manage.py test
```

### Database Commands

```bash
# Show all migrations
python manage.py showmigrations

# Reset database (WARNING: Deletes all data)
rm db.sqlite3
python manage.py migrate
python manage.py create_sample_data
```

---

## 🎨 VS Code Settings (Optional)

### Create `.vscode/settings.json`

Create a file: `.vscode/settings.json`

```json
{
    "python.defaultInterpreterPath": "${workspaceFolder}/venv/bin/python",
    "python.terminal.activateEnvironment": true,
    "python.linting.enabled": true,
    "python.linting.pylintEnabled": false,
    "python.formatting.provider": "black",
    "files.exclude": {
        "**/__pycache__": true,
        "**/*.pyc": true
    }
}
```

---

## 🔄 Complete Setup Checklist

- [ ] VS Code installed
- [ ] Python 3.8+ installed
- [ ] Project opened in VS Code
- [ ] Virtual environment created (`venv` folder exists)
- [ ] Virtual environment activated (see `(venv)` in terminal)
- [ ] Dependencies installed (`pip install -r requirements.txt`)
- [ ] Migrations created (`python manage.py makemigrations`)
- [ ] Database migrated (`python manage.py migrate`)
- [ ] Sample data loaded (`python manage.py create_sample_data`)
- [ ] Server running (`python manage.py runserver`)
- [ ] Application accessible at http://127.0.0.1:8000/
- [ ] Can login with test account

---

## 🚀 Next Steps After Setup

1. **Explore the Code:**
   - Check `maintenance/models.py` for database models
   - Check `maintenance/views.py` for business logic
   - Check `templates/` for HTML templates

2. **Customize:**
   - Modify models in `maintenance/models.py`
   - Add new views in `maintenance/views.py`
   - Update templates in `templates/maintenance/`

3. **Learn:**
   - Read `README.md` for features
   - Read `ARCHITECTURE.md` for system design
   - Read `QUICKSTART.md` for quick reference

---

## 💡 Pro Tips

1. **Use VS Code Integrated Terminal:**
   - Keep terminal open while coding
   - Server auto-reloads on file changes

2. **Enable Auto-Save:**
   - File → Auto Save (or `Ctrl + K, S`)

3. **Use Git (Optional):**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   ```

4. **Debug in VS Code:**
   - Set breakpoints in Python files
   - Press `F5` to start debugging
   - Select "Django" configuration

---

## 📞 Still Having Issues?

1. **Check Python Version:**
   ```bash
   python --version
   ```

2. **Check Virtual Environment:**
   ```bash
   which python  # Should point to venv/bin/python
   ```

3. **Verify Dependencies:**
   ```bash
   pip list
   # Should show: Django, django-crispy-forms, crispy-bootstrap5
   ```

4. **Check Django Installation:**
   ```bash
   python -c "import django; print(django.get_version())"
   # Should output: 4.2.7
   ```

---

## ✅ Success!

If you've completed all steps, you should now have:
- ✅ GearGuard running in VS Code
- ✅ Server accessible at http://127.0.0.1:8000/
- ✅ Sample data loaded
- ✅ Ready to develop!

**Happy Coding! 🎉**

---

*Last Updated: December 2024*

