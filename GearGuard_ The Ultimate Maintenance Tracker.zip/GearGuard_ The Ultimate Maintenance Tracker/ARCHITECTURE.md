# GearGuard System Architecture

## 📐 System Overview

GearGuard is a Django-based web application for maintenance management. It follows the Model-View-Template (MVT) architecture pattern.

## 🗄️ Database Schema

### Models and Relationships

```
Department (1) ──< (Many) Equipment
                    │
                    │ (assigned_team)
                    ▼
MaintenanceTeam (1) ──< (Many) Technician
                    │
                    │ (team)
                    ▼
            MaintenanceRequest
                    │
                    │ (equipment)
                    ▼
                Equipment
```

### Model Details

#### 1. Department
- **Purpose:** Company departments (Production, IT, Facilities)
- **Fields:** name, description, created_at
- **Relationships:** One-to-Many with Equipment

#### 2. MaintenanceTeam
- **Purpose:** Maintenance teams (Electrical, Mechanical, IT)
- **Fields:** name, description, created_at
- **Relationships:** 
  - One-to-Many with Technician
  - One-to-Many with Equipment (assigned_team)
  - One-to-Many with MaintenanceRequest

#### 3. Technician
- **Purpose:** Extended user model for technicians
- **Fields:** user (OneToOne), team (ForeignKey), phone, employee_id
- **Relationships:**
  - OneToOne with User (Django auth)
  - Many-to-One with MaintenanceTeam

#### 4. Equipment
- **Purpose:** Physical equipment tracking
- **Fields:** name, serial_number, department, location, purchase_date, warranty_expiry, assigned_team, status, description
- **Status Choices:** active, scrapped
- **Relationships:**
  - Many-to-One with Department
  - Many-to-One with MaintenanceTeam
  - One-to-Many with MaintenanceRequest

#### 5. MaintenanceRequest
- **Purpose:** Maintenance requests (corrective/preventive)
- **Fields:** equipment, request_type, team, technician, scheduled_date, duration_hours, status, description, notes, created_by, created_at, updated_at, completed_at
- **Request Types:** corrective, preventive
- **Status Choices:** new, in_progress, repaired, scrap
- **Relationships:**
  - Many-to-One with Equipment
  - Many-to-One with MaintenanceTeam
  - Many-to-One with Technician
  - Many-to-One with User (created_by)

## 🔄 Business Logic Flow

### Request Creation Flow

```
1. User selects Equipment
   ↓
2. System auto-fills Team (from equipment.assigned_team)
   ↓
3. Technician dropdown filters to show only team members
   ↓
4. User fills other details and saves
   ↓
5. Request created with status = "new"
```

### Technician Assignment Flow

```
1. Technician logs in
   ↓
2. Views request from their team
   ↓
3. Clicks "Assign Myself"
   ↓
4. System validates: technician.team == request.team
   ↓
5. If valid:
   - request.technician = technician
   - request.status = "in_progress"
   ↓
6. If invalid:
   - Error: "You can only assign yourself to requests from your team"
```

### Request Completion Flow

```
1. Technician (in_progress request) clicks "Mark as Repaired"
   ↓
2. System validates: request.status == "in_progress"
   ↓
3. Technician enters duration (optional)
   ↓
4. System updates:
   - request.status = "repaired"
   - request.duration_hours = entered_value
   - request.completed_at = now()
```

### Scrap Flow

```
1. User clicks "Mark as Scrap"
   ↓
2. System updates:
   - request.status = "scrap"
   - equipment.status = "scrapped"
   - request.completed_at = now()
```

## 🎨 View Architecture

### View Functions

1. **Authentication Views**
   - `register()` - User registration
   - `login()` - User login (Django built-in)
   - `logout()` - User logout (Django built-in)

2. **Dashboard Views**
   - `dashboard()` - Main dashboard with statistics

3. **Equipment Views**
   - `equipment_list()` - List all equipment with search/filter
   - `equipment_detail()` - Equipment details with maintenance history
   - `equipment_create()` - Create new equipment
   - `equipment_edit()` - Edit existing equipment

4. **Request Views**
   - `request_list()` - List all requests with filters
   - `request_detail()` - Request details with actions
   - `request_create()` - Create new request
   - `request_edit()` - Edit existing request
   - `assign_technician()` - Technician self-assignment
   - `mark_repaired()` - Mark request as repaired
   - `mark_as_scrap()` - Mark equipment as scrap

5. **Visualization Views**
   - `kanban_board()` - Kanban board with drag-and-drop
   - `update_request_status()` - API endpoint for status updates
   - `calendar_view()` - Calendar view for preventive maintenance

6. **Reporting Views**
   - `reports()` - Analytics and reports

7. **API Views**
   - `get_equipment_team()` - Get team for equipment (AJAX)

## 🔌 URL Routing

### URL Patterns

```
/                          → dashboard
/register/                 → register
/login/                    → login
/logout/                   → logout

/equipment/                 → equipment_list
/equipment/<id>/            → equipment_detail
/equipment/create/          → equipment_create
/equipment/<id>/edit/       → equipment_edit

/requests/                  → request_list
/requests/<id>/             → request_detail
/requests/create/           → request_create
/requests/<id>/edit/        → request_edit
/requests/<id>/assign/      → assign_technician
/requests/<id>/repaired/    → mark_repaired
/requests/<id>/scrap/       → mark_as_scrap

/kanban/                    → kanban_board
/kanban/<id>/update-status/ → update_request_status

/calendar/                  → calendar_view

/reports/                   → reports

/api/equipment-team/        → get_equipment_team
```

## 🎯 Key Features Implementation

### 1. Auto-Fill Team from Equipment

**Location:** `maintenance/forms.py` - `MaintenanceRequestForm.__init__()`

**Logic:**
- When equipment is selected, check if it has an assigned_team
- If yes, set team field initial value
- Filter technician queryset to show only team members

### 2. Drag-and-Drop Kanban

**Technology:** SortableJS library

**Implementation:**
- JavaScript initializes Sortable on each column
- On drop, AJAX call to `/kanban/<id>/update-status/`
- Server validates and updates status
- Page reloads to show updated state

### 3. Overdue Detection

**Location:** `maintenance/models.py` - `MaintenanceRequest.is_overdue()`

**Logic:**
- Check if scheduled_date exists and is in the past
- Check if status is not "repaired" or "scrap"
- Return True if overdue

### 4. Calendar Generation

**Location:** `maintenance/views.py` - `calendar_view()`

**Logic:**
- Use Python `calendar` module
- Generate month calendar grid
- Map requests to calendar days
- Highlight today and show events

## 🔐 Security Features

1. **Authentication Required**
   - All views (except login/register) require `@login_required`

2. **CSRF Protection**
   - Django CSRF middleware enabled
   - All forms include CSRF tokens

3. **Team-Based Access Control**
   - Technicians can only assign themselves to their team's requests
   - Validation in `assign_technician()` view

4. **Input Validation**
   - Django forms handle validation
   - Model validators ensure data integrity

## 📊 Data Flow Examples

### Example 1: Creating a Request

```
User Action: Fill form and submit
    ↓
POST /requests/create/
    ↓
MaintenanceRequestForm validation
    ↓
Auto-fill team from equipment
    ↓
Save to database
    ↓
Redirect to request detail
```

### Example 2: Kanban Drag & Drop

```
User Action: Drag card to new column
    ↓
JavaScript: SortableJS onEnd event
    ↓
AJAX POST /kanban/<id>/update-status/
    ↓
update_request_status() view
    ↓
Validate status transition
    ↓
Update database
    ↓
Return JSON response
    ↓
JavaScript: Reload page
```

## 🛠️ Technology Stack

- **Backend:** Django 4.2.7
- **Frontend:** Bootstrap 5, jQuery
- **Database:** SQLite (default, can use PostgreSQL/MySQL)
- **Forms:** django-crispy-forms
- **Drag & Drop:** SortableJS
- **Icons:** Bootstrap Icons

## 📝 Code Organization

```
maintenance/
├── models.py          # Database models
├── views.py          # View functions
├── forms.py          # Form definitions
├── urls.py           # URL routing
├── admin.py          # Admin configuration
└── management/
    └── commands/
        └── create_sample_data.py
```

## 🎓 Learning Points

This project demonstrates:
1. Django MVT architecture
2. Model relationships (ForeignKey, OneToOne)
3. Form handling and validation
4. Business logic in models and views
5. AJAX requests
6. Drag-and-drop interfaces
7. Calendar generation
8. Reporting and analytics
9. User authentication
10. Team-based access control

---

**Architecture designed for scalability and maintainability**

