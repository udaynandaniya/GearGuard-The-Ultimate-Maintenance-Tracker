"""
Forms for GearGuard Maintenance Management System
"""

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Equipment, MaintenanceRequest, Technician, MaintenanceTeam, Department


class UserRegistrationForm(UserCreationForm):
    """Form for user registration"""
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']


class EquipmentForm(forms.ModelForm):
    """Form for creating/editing equipment"""
    class Meta:
        model = Equipment
        fields = ['name', 'serial_number', 'department', 'location', 
                  'purchase_date', 'warranty_expiry', 'assigned_team', 
                  'status', 'description']
        widgets = {
            'purchase_date': forms.DateInput(attrs={'type': 'date'}),
            'warranty_expiry': forms.DateInput(attrs={'type': 'date'}),
            'description': forms.Textarea(attrs={'rows': 3}),
        }


class MaintenanceRequestForm(forms.ModelForm):
    """Form for creating/editing maintenance requests"""
    class Meta:
        model = MaintenanceRequest
        fields = ['equipment', 'request_type', 'team', 'technician', 
                  'scheduled_date', 'duration_hours', 'status', 
                  'description', 'notes']
        widgets = {
            'scheduled_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'description': forms.Textarea(attrs={'rows': 4}),
            'notes': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Auto-fill team when equipment is selected
        if self.data and 'equipment' in self.data:
            try:
                equipment_id = int(self.data.get('equipment'))
                equipment = Equipment.objects.get(pk=equipment_id)
                if equipment.assigned_team:
                    self.fields['team'].initial = equipment.assigned_team
                    # Filter technicians by team
                    self.fields['technician'].queryset = Technician.objects.filter(team=equipment.assigned_team)
            except (ValueError, Equipment.DoesNotExist):
                pass
        elif self.instance and self.instance.pk:
            # For editing existing request
            if self.instance.equipment and self.instance.equipment.assigned_team:
                self.fields['technician'].queryset = Technician.objects.filter(
                    team=self.instance.equipment.assigned_team
                )
        else:
            # Initial load - show all technicians or filter by team if equipment is pre-selected
            if 'equipment' in self.initial:
                try:
                    equipment_id = self.initial.get('equipment')
                    if equipment_id:
                        equipment = Equipment.objects.get(pk=equipment_id)
                        if equipment.assigned_team:
                            self.fields['team'].initial = equipment.assigned_team
                            self.fields['technician'].queryset = Technician.objects.filter(team=equipment.assigned_team)
                except (ValueError, Equipment.DoesNotExist):
                    pass


class TechnicianForm(forms.ModelForm):
    """Form for creating/editing technician profile"""
    class Meta:
        model = Technician
        fields = ['team', 'phone', 'employee_id']


class TeamForm(forms.ModelForm):
    """Form for creating/editing maintenance teams"""
    class Meta:
        model = MaintenanceTeam
        fields = ['name', 'description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }


class DepartmentForm(forms.ModelForm):
    """Form for creating/editing departments"""
    class Meta:
        model = Department
        fields = ['name', 'description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }

