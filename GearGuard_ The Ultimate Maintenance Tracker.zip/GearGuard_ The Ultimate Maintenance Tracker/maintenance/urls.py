"""
URL configuration for maintenance app
"""
from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    # Authentication
    path('register/', views.register, name='register'),
    path('login/', auth_views.LoginView.as_view(template_name='maintenance/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    
    # Dashboard
    path('', views.dashboard, name='dashboard'),
    
    # Equipment
    path('equipment/', views.equipment_list, name='equipment_list'),
    path('equipment/<int:pk>/', views.equipment_detail, name='equipment_detail'),
    path('equipment/create/', views.equipment_create, name='equipment_create'),
    path('equipment/<int:pk>/edit/', views.equipment_edit, name='equipment_edit'),
    
    # Maintenance Requests
    path('requests/', views.request_list, name='request_list'),
    path('requests/<int:pk>/', views.request_detail, name='request_detail'),
    path('requests/create/', views.request_create, name='request_create'),
    path('requests/<int:pk>/edit/', views.request_edit, name='request_edit'),
    path('requests/<int:pk>/assign/', views.assign_technician, name='assign_technician'),
    path('requests/<int:pk>/repaired/', views.mark_repaired, name='mark_repaired'),
    path('requests/<int:pk>/scrap/', views.mark_as_scrap, name='mark_as_scrap'),
    
    # Kanban Board
    path('kanban/', views.kanban_board, name='kanban_board'),
    path('kanban/<int:pk>/update-status/', views.update_request_status, name='update_request_status'),
    
    # Calendar View
    path('calendar/', views.calendar_view, name='calendar_view'),
    
    # Reports
    path('reports/', views.reports, name='reports'),
    
    # API endpoints
    path('api/equipment-team/', views.get_equipment_team, name='get_equipment_team'),
]

