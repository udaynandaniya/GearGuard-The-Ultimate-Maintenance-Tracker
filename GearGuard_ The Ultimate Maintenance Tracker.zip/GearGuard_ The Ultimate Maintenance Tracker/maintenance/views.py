"""
Views for GearGuard Maintenance Management System

This module contains all the views with business logic:
- Dashboard with statistics
- Equipment management
- Maintenance request management
- Kanban board view
- Calendar view
- Reporting
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Count, Q
from django.utils import timezone
from datetime import datetime, timedelta
from .models import (
    Equipment, MaintenanceRequest, Technician, 
    MaintenanceTeam, Department
)
from .forms import (
    EquipmentForm, MaintenanceRequestForm, 
    UserRegistrationForm, TechnicianForm
)


def register(request):
    """User registration view"""
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Create technician profile
            Technician.objects.create(user=user)
            messages.success(request, 'Registration successful! Please log in.')
            return redirect('login')
    else:
        form = UserRegistrationForm()
    return render(request, 'maintenance/register.html', {'form': form})


@login_required
def dashboard(request):
    """Main dashboard with statistics"""
    # Get statistics
    total_equipment = Equipment.objects.count()
    active_equipment = Equipment.objects.filter(status='active').count()
    total_requests = MaintenanceRequest.objects.count()
    new_requests = MaintenanceRequest.objects.filter(status='new').count()
    in_progress_requests = MaintenanceRequest.objects.filter(status='in_progress').count()
    overdue_requests = MaintenanceRequest.objects.filter(
        scheduled_date__lt=timezone.now(),
        status__in=['new', 'in_progress']
    ).count()
    
    # Get recent requests
    recent_requests = MaintenanceRequest.objects.select_related(
        'equipment', 'team', 'technician'
    ).order_by('-created_at')[:10]
    
    # Get requests by team
    requests_by_team = MaintenanceTeam.objects.annotate(
        request_count=Count('maintenancerequest')
    ).order_by('-request_count')[:5]
    
    # Get corrective vs preventive ratio
    corrective_count = MaintenanceRequest.objects.filter(request_type='corrective').count()
    preventive_count = MaintenanceRequest.objects.filter(request_type='preventive').count()
    
    context = {
        'total_equipment': total_equipment,
        'active_equipment': active_equipment,
        'total_requests': total_requests,
        'new_requests': new_requests,
        'in_progress_requests': in_progress_requests,
        'overdue_requests': overdue_requests,
        'recent_requests': recent_requests,
        'requests_by_team': requests_by_team,
        'corrective_count': corrective_count,
        'preventive_count': preventive_count,
    }
    return render(request, 'maintenance/dashboard.html', context)


@login_required
def equipment_list(request):
    """List all equipment"""
    equipment_list = Equipment.objects.select_related(
        'department', 'assigned_team'
    ).all()
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        equipment_list = equipment_list.filter(
            Q(name__icontains=search_query) |
            Q(serial_number__icontains=search_query) |
            Q(location__icontains=search_query)
        )
    
    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter:
        equipment_list = equipment_list.filter(status=status_filter)
    
    context = {
        'equipment_list': equipment_list,
        'search_query': search_query,
        'status_filter': status_filter,
    }
    return render(request, 'maintenance/equipment_list.html', context)


@login_required
def equipment_detail(request, pk):
    """Equipment detail view with maintenance history"""
    equipment = get_object_or_404(Equipment, pk=pk)
    maintenance_requests = MaintenanceRequest.objects.filter(
        equipment=equipment
    ).select_related('team', 'technician').order_by('-created_at')
    
    context = {
        'equipment': equipment,
        'maintenance_requests': maintenance_requests,
        'maintenance_count': equipment.get_maintenance_count(),
    }
    return render(request, 'maintenance/equipment_detail.html', context)


@login_required
def equipment_create(request):
    """Create new equipment"""
    if request.method == 'POST':
        form = EquipmentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Equipment created successfully!')
            return redirect('equipment_list')
    else:
        form = EquipmentForm()
    return render(request, 'maintenance/equipment_form.html', {'form': form, 'title': 'Add Equipment'})


@login_required
def equipment_edit(request, pk):
    """Edit existing equipment"""
    equipment = get_object_or_404(Equipment, pk=pk)
    if request.method == 'POST':
        form = EquipmentForm(request.POST, instance=equipment)
        if form.is_valid():
            form.save()
            messages.success(request, 'Equipment updated successfully!')
            return redirect('equipment_detail', pk=equipment.pk)
    else:
        form = EquipmentForm(instance=equipment)
    return render(request, 'maintenance/equipment_form.html', {'form': form, 'title': 'Edit Equipment', 'equipment': equipment})


@login_required
def request_list(request):
    """List all maintenance requests"""
    requests = MaintenanceRequest.objects.select_related(
        'equipment', 'team', 'technician'
    ).all()
    
    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter:
        requests = requests.filter(status=status_filter)
    
    # Filter by type
    type_filter = request.GET.get('type', '')
    if type_filter:
        requests = requests.filter(request_type=type_filter)
    
    context = {
        'requests': requests,
        'status_filter': status_filter,
        'type_filter': type_filter,
    }
    return render(request, 'maintenance/request_list.html', context)


@login_required
def request_detail(request, pk):
    """Maintenance request detail view"""
    maintenance_request = get_object_or_404(
        MaintenanceRequest.objects.select_related('equipment', 'team', 'technician'),
        pk=pk
    )
    
    # Check if current user is a technician
    try:
        technician = Technician.objects.get(user=request.user)
        can_assign = technician.team == maintenance_request.team
    except Technician.DoesNotExist:
        technician = None
        can_assign = False
    
    context = {
        'request': maintenance_request,
        'technician': technician,
        'can_assign': can_assign,
    }
    return render(request, 'maintenance/request_detail.html', context)


@login_required
def request_create(request):
    """Create new maintenance request"""
    if request.method == 'POST':
        form = MaintenanceRequestForm(request.POST)
        if form.is_valid():
            maintenance_request = form.save(commit=False)
            maintenance_request.created_by = request.user
            
            # Business Logic: Auto-fill team from equipment
            if maintenance_request.equipment and maintenance_request.equipment.assigned_team:
                maintenance_request.team = maintenance_request.equipment.assigned_team
            
            maintenance_request.save()
            messages.success(request, 'Maintenance request created successfully!')
            return redirect('request_detail', pk=maintenance_request.pk)
    else:
        # Check if equipment is pre-selected from query string
        initial_data = {}
        equipment_id = request.GET.get('equipment')
        if equipment_id:
            try:
                equipment = Equipment.objects.get(pk=equipment_id)
                initial_data['equipment'] = equipment
            except Equipment.DoesNotExist:
                pass
        form = MaintenanceRequestForm(initial=initial_data)
    return render(request, 'maintenance/request_form.html', {'form': form, 'title': 'Create Maintenance Request'})


@login_required
def request_edit(request, pk):
    """Edit existing maintenance request"""
    maintenance_request = get_object_or_404(MaintenanceRequest, pk=pk)
    
    if request.method == 'POST':
        form = MaintenanceRequestForm(request.POST, instance=maintenance_request)
        if form.is_valid():
            form.save()
            messages.success(request, 'Maintenance request updated successfully!')
            return redirect('request_detail', pk=maintenance_request.pk)
    else:
        form = MaintenanceRequestForm(instance=maintenance_request)
    
    return render(request, 'maintenance/request_form.html', {
        'form': form, 
        'title': 'Edit Maintenance Request',
        'request': maintenance_request
    })


@login_required
def assign_technician(request, pk):
    """Business Logic: Technician assigns themselves to a request"""
    maintenance_request = get_object_or_404(MaintenanceRequest, pk=pk)
    
    try:
        technician = Technician.objects.get(user=request.user)
        
        # Business Logic: Only team members can assign themselves
        if maintenance_request.team and technician.team != maintenance_request.team:
            messages.error(request, 'You can only assign yourself to requests from your team!')
            return redirect('request_detail', pk=pk)
        
        # Use the model method to assign technician
        maintenance_request.assign_technician(technician)
        messages.success(request, f'You have been assigned to this request. Status changed to "In Progress".')
        
    except Technician.DoesNotExist:
        messages.error(request, 'You must be a technician to assign yourself to requests.')
    except ValueError as e:
        messages.error(request, str(e))
    
    return redirect('request_detail', pk=pk)


@login_required
def mark_repaired(request, pk):
    """Business Logic: Mark request as repaired with time spent"""
    maintenance_request = get_object_or_404(MaintenanceRequest, pk=pk)
    
    if request.method == 'POST':
        duration_hours = request.POST.get('duration_hours')
        try:
            if duration_hours:
                duration_hours = float(duration_hours)
            else:
                duration_hours = None
            
            maintenance_request.mark_repaired(duration_hours)
            messages.success(request, 'Request marked as repaired!')
        except ValueError as e:
            messages.error(request, str(e))
    
    return redirect('request_detail', pk=pk)


@login_required
def mark_as_scrap(request, pk):
    """Business Logic: Mark equipment as scrap"""
    maintenance_request = get_object_or_404(MaintenanceRequest, pk=pk)
    
    if request.method == 'POST':
        maintenance_request.mark_as_scrap()
        messages.success(request, 'Equipment marked as scrap!')
    
    return redirect('request_detail', pk=pk)


@login_required
def kanban_board(request):
    """Kanban board view with drag and drop"""
    # Get requests grouped by status
    new_requests = MaintenanceRequest.objects.filter(
        status='new'
    ).select_related('equipment', 'team', 'technician').order_by('-created_at')
    
    in_progress_requests = MaintenanceRequest.objects.filter(
        status='in_progress'
    ).select_related('equipment', 'team', 'technician').order_by('-created_at')
    
    repaired_requests = MaintenanceRequest.objects.filter(
        status='repaired'
    ).select_related('equipment', 'team', 'technician').order_by('-completed_at')
    
    scrap_requests = MaintenanceRequest.objects.filter(
        status='scrap'
    ).select_related('equipment', 'team', 'technician').order_by('-completed_at')
    
    context = {
        'new_requests': new_requests,
        'in_progress_requests': in_progress_requests,
        'repaired_requests': repaired_requests,
        'scrap_requests': scrap_requests,
    }
    return render(request, 'maintenance/kanban_board.html', context)


@login_required
def update_request_status(request, pk):
    """API endpoint to update request status (for drag and drop)"""
    if request.method == 'POST':
        maintenance_request = get_object_or_404(MaintenanceRequest, pk=pk)
        new_status = request.POST.get('status')
        
        if new_status in dict(MaintenanceRequest.STATUS_CHOICES):
            old_status = maintenance_request.status
            maintenance_request.status = new_status
            
            # Business Logic: Handle status transitions
            if new_status == 'repaired' and old_status == 'in_progress':
                maintenance_request.completed_at = timezone.now()
            elif new_status == 'scrap':
                maintenance_request.mark_as_scrap()
                return JsonResponse({'success': True, 'message': 'Status updated and equipment marked as scrap'})
            
            maintenance_request.save()
            return JsonResponse({'success': True, 'message': 'Status updated successfully'})
        
        return JsonResponse({'success': False, 'message': 'Invalid status'})
    
    return JsonResponse({'success': False, 'message': 'Invalid request method'})


@login_required
def calendar_view(request):
    """Calendar view for preventive maintenance"""
    import calendar
    
    # Get all preventive maintenance requests
    preventive_requests = MaintenanceRequest.objects.filter(
        request_type='preventive',
        scheduled_date__isnull=False
    ).select_related('equipment', 'team', 'technician')
    
    # Get date range (current month)
    today = timezone.now().date()
    start_date = today.replace(day=1)
    if start_date.month == 12:
        end_date = start_date.replace(year=start_date.year + 1, month=1)
    else:
        end_date = start_date.replace(month=start_date.month + 1)
    
    # Filter requests for current month
    preventive_requests = preventive_requests.filter(
        scheduled_date__date__gte=start_date,
        scheduled_date__date__lt=end_date
    )
    
    # Group by date
    requests_by_date = {}
    for req in preventive_requests:
        date_key = req.scheduled_date.date()
        if date_key not in requests_by_date:
            requests_by_date[date_key] = []
        requests_by_date[date_key].append(req)
    
    # Generate calendar days
    cal = calendar.monthcalendar(start_date.year, start_date.month)
    calendar_days = []
    for week in cal:
        for day in week:
            if day == 0:
                # Day from previous/next month
                calendar_days.append({
                    'day': '',
                    'date': None,
                    'is_today': False,
                    'is_other_month': True
                })
            else:
                day_date = start_date.replace(day=day)
                calendar_days.append({
                    'day': day,
                    'date': day_date,
                    'is_today': day_date == today,
                    'is_other_month': False
                })
    
    context = {
        'preventive_requests': preventive_requests,
        'requests_by_date': requests_by_date,
        'calendar_days': calendar_days,
        'current_month': today.strftime('%B %Y'),
        'start_date': start_date,
        'end_date': end_date,
    }
    return render(request, 'maintenance/calendar_view.html', context)


@login_required
def reports(request):
    """Reporting dashboard"""
    # Requests per team
    requests_per_team = MaintenanceTeam.objects.annotate(
        request_count=Count('maintenancerequest')
    ).order_by('-request_count')
    
    # Equipment maintenance history
    equipment_history = Equipment.objects.annotate(
        request_count=Count('maintenancerequest')
    ).filter(request_count__gt=0).order_by('-request_count')[:10]
    
    # Corrective vs Preventive ratio
    corrective_count = MaintenanceRequest.objects.filter(request_type='corrective').count()
    preventive_count = MaintenanceRequest.objects.filter(request_type='preventive').count()
    total_requests = corrective_count + preventive_count
    
    # Status distribution
    status_distribution = MaintenanceRequest.objects.values('status').annotate(
        count=Count('id')
    )
    
    context = {
        'requests_per_team': requests_per_team,
        'equipment_history': equipment_history,
        'corrective_count': corrective_count,
        'preventive_count': preventive_count,
        'total_requests': total_requests,
        'status_distribution': status_distribution,
    }
    return render(request, 'maintenance/reports.html', context)


@login_required
def get_equipment_team(request):
    """API endpoint to get team for selected equipment (for auto-fill)"""
    equipment_id = request.GET.get('equipment_id')
    try:
        equipment = Equipment.objects.get(pk=equipment_id)
        if equipment.assigned_team:
            return JsonResponse({
                'success': True,
                'team_id': equipment.assigned_team.id,
                'team_name': equipment.assigned_team.name
            })
        return JsonResponse({'success': False, 'message': 'No team assigned'})
    except Equipment.DoesNotExist:
        return JsonResponse({'success': False, 'message': 'Equipment not found'})

