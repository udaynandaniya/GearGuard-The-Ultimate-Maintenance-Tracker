"""
Database Models for GearGuard Maintenance Management System

This module defines all the database models for the system:
- Department: Different departments in the company
- Equipment: Physical equipment that needs maintenance
- MaintenanceTeam: Teams responsible for maintenance
- Technician: Extended user model for technicians
- MaintenanceRequest: Maintenance requests (corrective/preventive)
"""

from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator
from django.utils import timezone


class Department(models.Model):
    """Represents a department in the company (Production, IT, etc.)"""
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class MaintenanceTeam(models.Model):
    """Represents a maintenance team (Electrical, Mechanical, IT, etc.)"""
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name

    def get_technicians(self):
        """Returns all technicians in this team"""
        return self.technician_set.all()


class Technician(models.Model):
    """
    Extended user model for technicians
    Links a User to a MaintenanceTeam
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    team = models.ForeignKey(MaintenanceTeam, on_delete=models.SET_NULL, null=True, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    employee_id = models.CharField(max_length=50, unique=True, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['user__first_name', 'user__last_name']

    def __str__(self):
        return f"{self.user.get_full_name()} ({self.team.name if self.team else 'No Team'})"

    def get_avatar_initials(self):
        """Returns initials for avatar display"""
        first = self.user.first_name[0] if self.user.first_name else ''
        last = self.user.last_name[0] if self.user.last_name else ''
        return (first + last).upper() or self.user.username[0].upper()


class Equipment(models.Model):
    """Represents physical equipment that needs maintenance"""
    
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('scrapped', 'Scrapped'),
    ]

    name = models.CharField(max_length=200)
    serial_number = models.CharField(max_length=100, unique=True)
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True)
    location = models.CharField(max_length=200)
    purchase_date = models.DateField()
    warranty_expiry = models.DateField(null=True, blank=True)
    assigned_team = models.ForeignKey(MaintenanceTeam, on_delete=models.SET_NULL, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active')
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']
        verbose_name_plural = 'Equipment'

    def __str__(self):
        return f"{self.name} ({self.serial_number})"

    def get_maintenance_count(self):
        """Returns the count of maintenance requests for this equipment"""
        return self.maintenancerequest_set.count()

    def is_under_warranty(self):
        """Checks if equipment is still under warranty"""
        if self.warranty_expiry:
            return timezone.now().date() <= self.warranty_expiry
        return False


class MaintenanceRequest(models.Model):
    """Represents a maintenance request (corrective or preventive)"""
    
    REQUEST_TYPE_CHOICES = [
        ('corrective', 'Corrective (Breakdown)'),
        ('preventive', 'Preventive (Scheduled)'),
    ]

    STATUS_CHOICES = [
        ('new', 'New'),
        ('in_progress', 'In Progress'),
        ('repaired', 'Repaired'),
        ('scrap', 'Scrap'),
    ]

    equipment = models.ForeignKey(Equipment, on_delete=models.CASCADE)
    request_type = models.CharField(max_length=20, choices=REQUEST_TYPE_CHOICES)
    team = models.ForeignKey(MaintenanceTeam, on_delete=models.SET_NULL, null=True, blank=True)
    technician = models.ForeignKey(Technician, on_delete=models.SET_NULL, null=True, blank=True)
    scheduled_date = models.DateTimeField(null=True, blank=True)
    duration_hours = models.DecimalField(
        max_digits=5, 
        decimal_places=2, 
        null=True, 
        blank=True,
        validators=[MinValueValidator(0)]
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='new')
    description = models.TextField()
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_requests')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.get_request_type_display()} - {self.equipment.name} ({self.get_status_display()})"

    def is_overdue(self):
        """Checks if the request is overdue"""
        if self.scheduled_date and self.status != 'repaired' and self.status != 'scrap':
            return timezone.now() > self.scheduled_date
        return False

    def assign_technician(self, technician):
        """Business logic: Assign technician and update status"""
        if self.team and technician.team != self.team:
            raise ValueError("Technician must be from the assigned team")
        self.technician = technician
        if self.status == 'new':
            self.status = 'in_progress'
        self.save()

    def mark_repaired(self, duration_hours=None):
        """Business logic: Mark as repaired with time spent"""
        if self.status != 'in_progress':
            raise ValueError("Request must be in progress before marking as repaired")
        self.status = 'repaired'
        if duration_hours:
            self.duration_hours = duration_hours
        self.completed_at = timezone.now()
        self.save()

    def mark_as_scrap(self):
        """Business logic: Mark equipment as scrap"""
        self.status = 'scrap'
        self.equipment.status = 'scrapped'
        self.equipment.save()
        self.completed_at = timezone.now()
        self.save()

