"""
Management command to create sample data for testing GearGuard

Usage: python manage.py create_sample_data
"""

from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import timedelta
from maintenance.models import (
    Department, MaintenanceTeam, Technician, 
    Equipment, MaintenanceRequest
)


class Command(BaseCommand):
    help = 'Creates sample data for GearGuard system'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Creating sample data...'))
        
        # Create Departments
        self.stdout.write('Creating departments...')
        dept_production = Department.objects.get_or_create(
            name='Production',
            defaults={'description': 'Production Department'}
        )[0]
        dept_it = Department.objects.get_or_create(
            name='IT',
            defaults={'description': 'Information Technology Department'}
        )[0]
        dept_facilities = Department.objects.get_or_create(
            name='Facilities',
            defaults={'description': 'Facilities Management'}
        )[0]
        
        # Create Maintenance Teams
        self.stdout.write('Creating maintenance teams...')
        team_electrical = MaintenanceTeam.objects.get_or_create(
            name='Electrical Team',
            defaults={'description': 'Handles electrical equipment maintenance'}
        )[0]
        team_mechanical = MaintenanceTeam.objects.get_or_create(
            name='Mechanical Team',
            defaults={'description': 'Handles mechanical equipment maintenance'}
        )[0]
        team_it = MaintenanceTeam.objects.get_or_create(
            name='IT Support Team',
            defaults={'description': 'Handles IT equipment maintenance'}
        )[0]
        
        # Create Users and Technicians
        self.stdout.write('Creating users and technicians...')
        
        # Electrical Technicians
        user1, created = User.objects.get_or_create(
            username='john.electrician',
            defaults={
                'first_name': 'John',
                'last_name': 'Smith',
                'email': 'john@example.com'
            }
        )
        if created:
            user1.set_password('password123')
            user1.save()
        tech1, _ = Technician.objects.get_or_create(
            user=user1,
            defaults={
                'team': team_electrical,
                'phone': '555-0101',
                'employee_id': 'EMP001'
            }
        )
        tech1.team = team_electrical
        tech1.save()
        
        user2, created = User.objects.get_or_create(
            username='jane.electrician',
            defaults={
                'first_name': 'Jane',
                'last_name': 'Doe',
                'email': 'jane@example.com'
            }
        )
        if created:
            user2.set_password('password123')
            user2.save()
        tech2, _ = Technician.objects.get_or_create(
            user=user2,
            defaults={
                'team': team_electrical,
                'phone': '555-0102',
                'employee_id': 'EMP002'
            }
        )
        tech2.team = team_electrical
        tech2.save()
        
        # Mechanical Technicians
        user3, created = User.objects.get_or_create(
            username='bob.mechanic',
            defaults={
                'first_name': 'Bob',
                'last_name': 'Johnson',
                'email': 'bob@example.com'
            }
        )
        if created:
            user3.set_password('password123')
            user3.save()
        tech3, _ = Technician.objects.get_or_create(
            user=user3,
            defaults={
                'team': team_mechanical,
                'phone': '555-0103',
                'employee_id': 'EMP003'
            }
        )
        tech3.team = team_mechanical
        tech3.save()
        
        # IT Technicians
        user4, created = User.objects.get_or_create(
            username='alice.itsupport',
            defaults={
                'first_name': 'Alice',
                'last_name': 'Williams',
                'email': 'alice@example.com'
            }
        )
        if created:
            user4.set_password('password123')
            user4.save()
        tech4, _ = Technician.objects.get_or_create(
            user=user4,
            defaults={
                'team': team_it,
                'phone': '555-0104',
                'employee_id': 'EMP004'
            }
        )
        tech4.team = team_it
        tech4.save()
        
        # Create Equipment
        self.stdout.write('Creating equipment...')
        
        equipment1, _ = Equipment.objects.get_or_create(
            serial_number='EQ001',
            defaults={
                'name': 'Production Line Conveyor Belt',
                'department': dept_production,
                'location': 'Factory Floor A',
                'purchase_date': timezone.now().date() - timedelta(days=365*2),
                'warranty_expiry': timezone.now().date() + timedelta(days=30),
                'assigned_team': team_mechanical,
                'status': 'active',
                'description': 'Main conveyor belt for production line'
            }
        )
        
        equipment2, _ = Equipment.objects.get_or_create(
            serial_number='EQ002',
            defaults={
                'name': 'Industrial Generator',
                'department': dept_production,
                'location': 'Power Room',
                'purchase_date': timezone.now().date() - timedelta(days=365*3),
                'warranty_expiry': timezone.now().date() - timedelta(days=30),
                'assigned_team': team_electrical,
                'status': 'active',
                'description': 'Backup power generator'
            }
        )
        
        equipment3, _ = Equipment.objects.get_or_create(
            serial_number='EQ003',
            defaults={
                'name': 'Server Rack Unit',
                'department': dept_it,
                'location': 'Data Center',
                'purchase_date': timezone.now().date() - timedelta(days=365),
                'warranty_expiry': timezone.now().date() + timedelta(days=180),
                'assigned_team': team_it,
                'status': 'active',
                'description': 'Main server rack for data center'
            }
        )
        
        equipment4, _ = Equipment.objects.get_or_create(
            serial_number='EQ004',
            defaults={
                'name': 'HVAC System',
                'department': dept_facilities,
                'location': 'Building A',
                'purchase_date': timezone.now().date() - timedelta(days=365*4),
                'warranty_expiry': None,
                'assigned_team': team_mechanical,
                'status': 'active',
                'description': 'Heating, ventilation, and air conditioning system'
            }
        )
        
        equipment5, _ = Equipment.objects.get_or_create(
            serial_number='EQ005',
            defaults={
                'name': 'Network Switch',
                'department': dept_it,
                'location': 'IT Office',
                'purchase_date': timezone.now().date() - timedelta(days=180),
                'warranty_expiry': timezone.now().date() + timedelta(days=90),
                'assigned_team': team_it,
                'status': 'active',
                'description': '48-port network switch'
            }
        )
        
        # Create Maintenance Requests
        self.stdout.write('Creating maintenance requests...')
        
        # Corrective (Breakdown) Requests
        req1, _ = MaintenanceRequest.objects.get_or_create(
            equipment=equipment2,
            description='Generator not starting',
            defaults={
                'request_type': 'corrective',
                'team': team_electrical,
                'technician': tech1,
                'status': 'in_progress',
                'scheduled_date': timezone.now() - timedelta(hours=2),
                'created_by': user1
            }
        )
        
        req2, _ = MaintenanceRequest.objects.get_or_create(
            equipment=equipment1,
            description='Conveyor belt making unusual noise',
            defaults={
                'request_type': 'corrective',
                'team': team_mechanical,
                'status': 'new',
                'scheduled_date': timezone.now() + timedelta(hours=4),
                'created_by': user3
            }
        )
        
        req3, _ = MaintenanceRequest.objects.get_or_create(
            equipment=equipment5,
            description='Network switch intermittent connectivity',
            defaults={
                'request_type': 'corrective',
                'team': team_it,
                'technician': tech4,
                'status': 'repaired',
                'scheduled_date': timezone.now() - timedelta(days=1),
                'duration_hours': 2.5,
                'completed_at': timezone.now() - timedelta(hours=12),
                'created_by': user4
            }
        )
        
        # Preventive (Scheduled) Requests
        req4, _ = MaintenanceRequest.objects.get_or_create(
            equipment=equipment3,
            description='Monthly server maintenance',
            defaults={
                'request_type': 'preventive',
                'team': team_it,
                'status': 'new',
                'scheduled_date': timezone.now() + timedelta(days=5),
                'created_by': user4
            }
        )
        
        req5, _ = MaintenanceRequest.objects.get_or_create(
            equipment=equipment4,
            description='Quarterly HVAC filter replacement',
            defaults={
                'request_type': 'preventive',
                'team': team_mechanical,
                'status': 'new',
                'scheduled_date': timezone.now() + timedelta(days=10),
                'created_by': user3
            }
        )
        
        req6, _ = MaintenanceRequest.objects.get_or_create(
            equipment=equipment2,
            description='Annual generator service',
            defaults={
                'request_type': 'preventive',
                'team': team_electrical,
                'status': 'new',
                'scheduled_date': timezone.now() + timedelta(days=15),
                'created_by': user1
            }
        )
        
        # Overdue request
        req7, _ = MaintenanceRequest.objects.get_or_create(
            equipment=equipment1,
            description='Overdue maintenance check',
            defaults={
                'request_type': 'preventive',
                'team': team_mechanical,
                'status': 'new',
                'scheduled_date': timezone.now() - timedelta(days=2),
                'created_by': user3
            }
        )
        
        self.stdout.write(self.style.SUCCESS('\nSample data created successfully!'))
        self.stdout.write(self.style.SUCCESS('\nTest Accounts:'))
        self.stdout.write('  - john.electrician / password123 (Electrical Team)')
        self.stdout.write('  - jane.electrician / password123 (Electrical Team)')
        self.stdout.write('  - bob.mechanic / password123 (Mechanical Team)')
        self.stdout.write('  - alice.itsupport / password123 (IT Support Team)')

