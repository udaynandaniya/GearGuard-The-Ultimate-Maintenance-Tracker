from django.contrib import admin
from .models import Department, Equipment, MaintenanceTeam, Technician, MaintenanceRequest


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ['name', 'description', 'created_at']
    search_fields = ['name']


@admin.register(MaintenanceTeam)
class MaintenanceTeamAdmin(admin.ModelAdmin):
    list_display = ['name', 'description', 'created_at']
    search_fields = ['name']


@admin.register(Technician)
class TechnicianAdmin(admin.ModelAdmin):
    list_display = ['user', 'team', 'phone', 'employee_id']
    list_filter = ['team']
    search_fields = ['user__username', 'user__first_name', 'user__last_name', 'employee_id']


@admin.register(Equipment)
class EquipmentAdmin(admin.ModelAdmin):
    list_display = ['name', 'serial_number', 'department', 'location', 'assigned_team', 'status']
    list_filter = ['status', 'department', 'assigned_team']
    search_fields = ['name', 'serial_number', 'location']
    date_hierarchy = 'purchase_date'


@admin.register(MaintenanceRequest)
class MaintenanceRequestAdmin(admin.ModelAdmin):
    list_display = ['equipment', 'request_type', 'status', 'team', 'technician', 'scheduled_date', 'created_at']
    list_filter = ['status', 'request_type', 'team', 'created_at']
    search_fields = ['equipment__name', 'description']
    date_hierarchy = 'created_at'
    readonly_fields = ['created_at', 'updated_at', 'completed_at']

